import requests
import traceback

import bittensor as bt


from redteam_core.challenge_pool import docker_utils
from redteam_core.challenge_pool.controller import Controller
from redteam_core.config.main import constants
from redteam_core.validator.models import MinerChallengeCommit, ScoringLog


class ABSController(Controller):
    """
    A specialized controller for the 'ab_sniffer_v5' challenge.
    Inherits from the base Controller and modifies specific logic.
    """

    def __init__(
        self,
        challenge_name: str,
        challenge_info: dict,
        miner_commits: list[MinerChallengeCommit],
        reference_comparison_commits: list[MinerChallengeCommit],
        seed_inputs: list[dict] = [],
    ):
        """
        Initializes the ABSController, extending the original Controller.
        """
        super().__init__(
            challenge_name,
            challenge_info,
            miner_commits,
            reference_comparison_commits,
            seed_inputs,
        )

        comparison_config = self.challenge_info.get("comparison_config", {})
        self.comparison_min_acceptable_score = comparison_config.get(
            "min_acceptable_score", 0.6
        )

    def start_challenge(self):
        """
        Initiates the challenge lifecycle by setting up and executing the challenge Docker container.

        This process involves:
        1. Building and running the challenge container within an isolated Docker network.
        2. Generating or retrieving challenge inputs to evaluate miners.
        3. Iteratively running each miner's Docker container to submit and score their solutions.
        4. Collecting and logging the results, including any errors encountered during execution.
        5. Cleaning up Docker resources to ensure no residual containers or images remain.

        The method ensures that each miner's submission is evaluated against the challenge inputs,
        and comparison logs are generated to assess performance relative to reference commits.
        """
        self._setup_challenge()

        num_task = self.challenge_info.get(
            "num_tasks", constants.N_CHALLENGES_PER_EPOCH
        )
        # Start with seed inputs and generate more if needed to reach num_task
        challenge_inputs = self.seed_inputs.copy()
        remaining_tasks = max(0, num_task - len(challenge_inputs))
        if remaining_tasks > 0:
            challenge_inputs.extend(
                [self._get_challenge_from_container() for _ in range(remaining_tasks)]
            )

        bt.logging.debug(
            f"[CONTROLLER - ABSController] Generated {len(challenge_inputs)} challenge inputs"
        )

        for miner_commit in self.miner_commits:
            uid, hotkey = miner_commit.miner_uid, miner_commit.miner_hotkey

            try:
                self._setup_miner_container(miner_commit)

                self._generate_scoring_logs(miner_commit, challenge_inputs)

                self._run_reference_comparison_inputs(miner_commit)

                self._score_miner_with_new_inputs(miner_commit, challenge_inputs)

            except Exception as e:
                bt.logging.error(f"Error while processing miner {uid} - {hotkey}: {e}")
                bt.logging.error(traceback.format_exc())
                miner_commit.scoring_logs.append(
                    ScoringLog(
                        miner_input=None,
                        miner_output=None,
                        score=0,
                        error=str(e),
                    )
                )

            docker_utils.remove_container_by_port(
                client=self.docker_client,
                port=constants.MINER_DOCKER_PORT,
            )
            docker_utils.clean_docker_resources(
                client=self.docker_client,
                remove_containers=True,
                remove_images=False,
            )

        bt.logging.debug(
            f"[CONTROLLER - ABSController] Challenge completed, cleaning up challenge container"
        )

        docker_utils.remove_container(
            client=self.docker_client,
            container_name=self.challenge_name,
            stop_timeout=10,
            force=True,
            remove_volumes=True,
        )
        docker_utils.clean_docker_resources(
            client=self.docker_client,
            remove_containers=True,
            remove_images=False,
        )

    def _score_miner_with_new_inputs(
        self, miner_commit: MinerChallengeCommit, challenge_inputs
    ):
        _scoring_log = miner_commit.scoring_logs[0]
        for i, miner_input in enumerate(challenge_inputs):

            _higest_comparison_score = miner_commit.get_higest_comparison_score()

            if (
                _higest_comparison_score >= self.comparison_min_acceptable_score
                or _higest_comparison_score == 0.0
            ):
                bt.logging.info(
                    f"[CONTROLLER - ABSController] Skipping scoring for miner {miner_commit.miner_hotkey} on task {i} due to high comparison score: {_higest_comparison_score}"
                )
                _scoring_log.score = 0.0
                if _scoring_log.error:
                    _scoring_log.error += (
                        " | Skipped scoring due to high comparison score."
                    )
                else:
                    _scoring_log.error = "Skipped scoring due to high comparison score."
                continue

            score = (
                self._score_challenge(
                    miner_input=miner_input,
                    miner_output=_scoring_log.miner_output,
                    task_id=i,
                )
                if _scoring_log.miner_output is not None
                else 0.0
            )
            scoring_results = self._get_scoring_results()

            _scoring_log.miner_output["scoring_results"] = scoring_results
            _scoring_log.score = score

    def _get_scoring_results(self) -> dict:
        """Retrieve scoring results from the challenge container."""

        _protocol, _ssl_verify = self._check_protocol(is_challenger=True)
        try:
            bt.logging.debug(f"[CONTROLLER] Getting scoring results ...")
            response = requests.get(
                f"{_protocol}://localhost:{constants.CHALLENGE_DOCKER_PORT}/results",
                verify=_ssl_verify,
                headers=self.challenge_info.get("scoring_headers", {}),
            )
            scoring_results = response.json()
        except Exception as ex:
            bt.logging.error(f"Score challenge failed: {str(ex)}")
            scoring_results = {}

        return scoring_results

    def _exclude_output_keys(self, miner_output: dict, reference_output: dict):
        miner_output["detection_files"] = None
        reference_output["detection_files"] = None
        miner_output["scoring_results"] = None
        reference_output["scoring_results"] = None
