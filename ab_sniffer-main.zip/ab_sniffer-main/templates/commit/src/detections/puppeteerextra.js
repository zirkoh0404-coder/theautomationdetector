function detect_puppeteerextra() {
  try {
    if (typeof window.stripProxyFromErrors !== 'undefined') return true;
    if (typeof window.__puppeteer_extra__ !== 'undefined') return true;
    if (typeof window.__puppeteer_evaluation__ !== 'undefined') return true;
    if (window.__puppeteer__ || window.__PUPPETEER_WORLD__) return true;
    var props = Object.getOwnPropertyNames(window).join(' ').toLowerCase();
    if (/stripproxyfromerrors|__puppeteer_extra|__puppeteer_evaluation|__puppeteer__|__puppeteer_world/.test(props)) return true;
    var d = Object.getOwnPropertyDescriptor(navigator, 'webdriver');
    if (d && d.get) {
      var g = d.get.toString().toLowerCase();
      if (g.indexOf('puppeteer') !== -1 && g.indexOf('seleniumbase') === -1 && g.indexOf('nodriver') === -1 && g.indexOf('botasaurus') === -1 && g.indexOf('patchright') === -1 && g.indexOf('zendriver') === -1 && g.indexOf('pydoll') === -1 && g.indexOf('selenium_driverless') === -1) return true;
    }
  } catch (e) {}
  return false;
}
if (typeof window !== 'undefined') window.detect_puppeteerextra = detect_puppeteerextra;
