function detect_zendriver() {
  try {
    if (typeof window.zendriver_cf_solver_ready === 'boolean' && window.zendriver_cf_solver_ready === true) return true;
    if (typeof window.__zendriver__ !== 'undefined') return true;
    if (typeof window.zendriver_cloudflare_bypass !== 'undefined') return true;
    var props = Object.getOwnPropertyNames(window).concat(document ? Object.getOwnPropertyNames(document) : []);
    if (/zendriver_cf_solver_ready|__zendriver__|zendriver_cloudflare_bypass/.test(props.join(' ').toLowerCase())) return true;
    var d = Object.getOwnPropertyDescriptor(navigator, 'webdriver');
    if (d && d.get) {
      var g = d.get.toString().toLowerCase();
      if (g.indexOf('zendriver') !== -1) return true;
    }
  } catch (e) {}
  return false;
}
if (typeof window !== 'undefined') window.detect_zendriver = detect_zendriver;
