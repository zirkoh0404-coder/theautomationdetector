function detect_seleniumdriverless() {
  try {
    if (typeof window.selenium_driverless_context_manager !== 'undefined') return true;
    if (typeof window.__selenium_driverless__ !== 'undefined') return true;
    if ((window.__selenium_unwrapped || window.__selenium_evaluate) && (navigator.webdriver === false || navigator.webdriver === undefined) && !window.cdc_adoQpoasnfa76pfcZLmcfl_Array && !window.SB_UC_MODE) return true;
    var props = Object.getOwnPropertyNames(window).concat(document ? Object.getOwnPropertyNames(document) : []);
    var s = props.join(' ').toLowerCase();
    if (/selenium_driverless_context_manager|__selenium_driverless__/.test(s)) return true;
    var d = Object.getOwnPropertyDescriptor(navigator, 'webdriver');
    if (d && d.get) {
      var g = d.get.toString().toLowerCase();
      if (g.indexOf('selenium') !== -1 && g.indexOf('driverless') !== -1 && g.indexOf('puppeteer') === -1 && g.indexOf('nodriver') === -1 && g.indexOf('botasaurus') === -1 && g.indexOf('patchright') === -1) return true;
    }
  } catch (e) {}
  return false;
}
if (typeof window !== 'undefined') window.detect_seleniumdriverless = detect_seleniumdriverless;
