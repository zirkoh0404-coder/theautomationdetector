# How Detection Functions Are Checked with Docker

## Complete Flow Overview

This document explains how the challenge system tests your detection functions using Docker containers.

## Flow Diagram

```
1. Miner submits detection files
   ↓
2. Router receives POST /score
   ↓
3. Service copies detection files to templates/
   ↓
4. Service generates 27 test sessions (8 frameworks × 3 + human × 3)
   ↓
5. For each session:
   ├─ Run Docker container with automation framework
   ├─ Container loads HTML page from /_web
   ├─ HTML loads all detection scripts
   ├─ React app runs detection functions
   ├─ Results submitted to /_payload
   └─ Service evaluates and scores
   ↓
6. Calculate final score
```

## Step-by-Step Detailed Flow

### Step 1: Miner Submits Detection Files

**File**: `src/api/endpoints/challenge/router.py`
**Endpoint**: `POST /score`

```python
def post_score(request: Request, miner_input: MinerInput, miner_output: MinerOutput):
    # Receives detection files from miner
    # Calls service.score() to evaluate
    _score = service.score(miner_output=miner_output, web_url=web_url)
    return _score
```

**Input Format**:
```json
{
  "miner_input": {...},
  "miner_output": {
    "detection_files": [
      {"file_name": "nodriver.js", "content": "function detect_nodriver() {...}"},
      {"file_name": "seleniumbase.js", "content": "function detect_seleniumbase() {...}"},
      ...
    ]
  }
}
```

### Step 2: Copy Detection Files to Templates Directory

**File**: `src/api/endpoints/challenge/service.py` (line 43-49)
**Function**: `score()`

```python
# Copy detection files to templates/static/detections/
_detections_dir = str(_src_dir / "templates" / "static" / "detections")
ch_utils.copy_detection_files(
    miner_output=miner_output,
    detections_dir=_detections_dir,
)
```

**What happens**:
- Creates `src/templates/static/detections/` directory if needed
- Writes each detection file (nodriver.js, seleniumbase.js, etc.) to disk
- These files are now accessible to the HTML page

### Step 3: Generate Test Sessions

**File**: `src/api/endpoints/challenge/service.py` (line 39)
**File**: `src/api/endpoints/challenge/_payload_manager.py` (line 118-137)

```python
payload_manager.restart_manager()  # Generates 27 sessions
_all_tasks = payload_manager.tasks  # Contains all 27 tasks
```

**What happens**:
- `gen_ran_framework_sequence()` creates 27 test sessions:
  - 8 automation frameworks × 3 repetitions = 24 sessions
  - 1 human scenario × 3 repetitions = 3 sessions
  - Total: 27 sessions (order numbers 0-26)
- Each session has:
  - `order_number`: 0-26
  - `name`: framework name (e.g., "nodriver", "seleniumbase", "human")
  - `image`: Docker image to run
  - `status`: CREATED → RUNNING → COMPLETED/TIMED_OUT/FAILED

### Step 4: Run Docker Container for Each Session

**File**: `src/api/endpoints/challenge/service.py` (line 57-98)
**File**: `src/api/endpoints/challenge/utils.py` (line 36-94)

```python
for _framework in _all_tasks.values():
    _framework_name = _framework["name"]  # e.g., "nodriver"
    _framework_image = _framework["image"]  # Docker image
    
    # Run Docker container
    ch_utils.run_bot_container(
        docker_client=_docker_client,
        container_name=_framework_name,
        network_name="local_network",
        image_name=_framework_image,
        ulimit=config.challenge.docker_ulimit,
    )
```

**What `run_bot_container()` does**:

1. **Creates Docker Network** (if not exists):
   ```python
   _network = docker_client.networks.create(
       name="local_network", 
       driver="bridge", 
       internal=True
   )
   ```

2. **Gets Gateway IP**:
   ```python
   _gateway_ip = _network_info["IPAM"]["Config"][0]["Gateway"]
   # e.g., "172.18.0.1"
   ```

3. **Constructs Web URL**:
   ```python
   _web_url = f"http://{_gateway_ip}:{config.api.port}/_web"
   # e.g., "http://172.18.0.1:10001/_web"
   ```

4. **Runs Docker Container**:
   ```python
   _container = docker_client.containers.run(
       image=_framework_image,  # e.g., "redteamsubnet61/nodriver@sha256:..."
       name=_framework_name,     # e.g., "nodriver"
       environment={
           "ABS_WEB_URL": _web_url,
           "RANDOM_WAIT": str(_waiting_time)
       },
       network="local_network",
       detach=True,
   )
   ```

**What the Docker container does**:
- The automation framework (nodriver, seleniumbase, etc.) runs inside the container
- It receives `ABS_WEB_URL` environment variable
- It navigates to that URL (which serves the HTML page)
- The framework executes JavaScript on that page

### Step 5: Serve HTML Page with Detection Scripts

**File**: `src/api/endpoints/challenge/router.py` (line 98-125)
**File**: `src/api/endpoints/challenge/service.py` (line 211-238)
**Endpoint**: `GET /_web`

```python
def get_web(request: Request) -> HTMLResponse:
    # Get current task order number
    _order_number = payload_manager.current_task["order_number"]
    
    # Construct result endpoint
    _abs_result_endpoint = f"http://{server_ip}:{port}/_payload"
    
    # Render HTML template
    html_response = templates.TemplateResponse(
        name="index.html",
        context={
            "abs_result_endpoint": _abs_result_endpoint,
            "abs_session_order_number": _order_number,
            "asb_framework_names": ["nodriver", "seleniumbase", ...],
        },
    )
    return html_response
```

**HTML Template** (`src/templates/index.html`):

```html
<!-- Sets global variables -->
<script>
  window.ABS_RESULT_ENDPOINT = "http://172.18.0.1:10001/_payload";
  window.ABS_SESSION_ORDER_NUMBER = 0;
  window.ASB_FRAMEWORK_NAMES = ["nodriver", "seleniumbase", ...];
</script>

<!-- Loads all detection scripts -->
<script src="static/detections/nodriver.js"></script>
<script src="static/detections/seleniumbase.js"></script>
<!-- ... etc ... -->

<!-- React app runs detections and submits results -->
<script src="static/js/main.e9cd64cf.js"></script>
```

**What happens**:
- HTML page loads in the Docker container's browser
- All detection scripts are loaded from `static/detections/*.js`
- React app (`main.e9cd64cf.js`) runs all detection functions
- Results are collected and submitted

### Step 6: Detection Functions Execute

**Location**: Inside Docker container's browser
**Files**: `src/templates/static/detections/*.js`

The React app (`main.e9cd64cf.js`) does:

```javascript
// For each framework in ASB_FRAMEWORK_NAMES:
const results = [];

frameworkNames.forEach(name => {
    const detectFn = window[`detect_${name}`];
    if (detectFn) {
        const detected = detectFn();  // Call your detection function
        results.push({
            framework_name: name,
            detected: detected === true,
            raw: detected
        });
    }
});

// Submit to server
fetch(window.ABS_RESULT_ENDPOINT, {
    method: 'POST',
    body: JSON.stringify({
        results: results,
        order_number: window.ABS_SESSION_ORDER_NUMBER
    })
});
```

**Your detection functions**:
- `detect_nodriver()` - Returns `true` if nodriver detected, `false` otherwise
- `detect_seleniumbase()` - Returns `true` if seleniumbase detected, `false` otherwise
- etc.

### Step 7: Submit Detection Results

**File**: `src/api/endpoints/challenge/router.py` (line 128-153)
**Endpoint**: `POST /_payload`

```python
def post_payload(request: Request, body: SubmissionPayloadsPM):
    # Receives detection results from browser
    # body.results = [
    #     {"framework_name": "nodriver", "detected": True, "raw": True},
    #     {"framework_name": "seleniumbase", "detected": False, "raw": False},
    #     ...
    # ]
    # body.order_number = 0
    
    service.submit_payload(body)
```

**Payload Format**:
```json
{
  "results": [
    {"framework_name": "nodriver", "detected": true, "raw": true},
    {"framework_name": "seleniumbase", "detected": false, "raw": false},
    {"framework_name": "puppeteerextra", "detected": false, "raw": false},
    ...
  ],
  "order_number": 0
}
```

### Step 8: Evaluate Results

**File**: `src/api/endpoints/challenge/service.py` (line 183-208)
**File**: `src/api/endpoints/challenge/_payload_manager.py` (line 32-61)

```python
def submit_payload(_payload: SubmissionPayloadsPM):
    # Get detected frameworks (where detected=True)
    _final_results = _payload.get_final_results()
    # e.g., ["nodriver"]
    
    # Check against expected framework
    _expected = payload_manager.expected_order[_payload.order_number]
    # e.g., "nodriver"
    
    # Store result
    payload_manager.submit_task(
        framework_names=_final_results,
        payload=_payload.model_dump(),
    )
```

**Evaluation Logic**:
- **Perfect Detection**: Expected framework is in detected list, and only one framework detected
  - Score: +1.0
- **Collision**: Expected framework is in detected list, but multiple frameworks detected
  - Score: +0.1
- **Failed**: Expected framework not in detected list
  - Score: +0.0
- **Human**: Must detect nothing (no frameworks)
  - If detects any framework → Score: 0.0 (fail entire challenge)

### Step 9: Wait for All Sessions to Complete

**File**: `src/api/endpoints/challenge/service.py` (line 100-138)

```python
while True:
    if payload_manager.check_task_compliance(_framework_order):
        # Detection completed for this session
        payload_manager.update_task_status(_framework_order, TaskStatusEnum.COMPLETED)
        ch_utils.stop_container(container_name=_framework_name)
        break
    
    _bot_timeout -= 1
    if _bot_timeout <= 0:
        # Timeout - no detection received
        payload_manager.update_task_status(_framework_order, TaskStatusEnum.TIMED_OUT)
        ch_utils.stop_container(container_name=_framework_name)
        break
    
    time.sleep(1)  # Wait 1 second, check again
```

**What happens**:
- Service waits for payload submission for each session
- If payload received → Mark as COMPLETED, stop container
- If timeout (10 seconds for bots, 120 seconds for human) → Mark as TIMED_OUT, stop container
- Moves to next session

### Step 10: Calculate Final Score

**File**: `src/api/endpoints/challenge/service.py` (line 151)
**File**: `src/api/endpoints/challenge/_payload_manager.py` (line 63-116)

```python
_score = payload_manager.calculate_score()
```

**Score Calculation**:
```python
def calculate_score(self) -> float:
    # Check human detection first (must pass)
    if human_detection_failed:
        return 0.0  # Fail entire challenge
    
    # Calculate points
    _total_points = (
        _correct_detections * 1.0 +    # Perfect detections
        _collision_detections * 0.1    # Collision detections
    )
    
    # Final score = total_points / total_sessions
    self.score = _total_points / _total_tasks
    return self.score
```

**Example**:
- 27 total sessions
- 20 perfect detections → 20.0 points
- 5 collision detections → 0.5 points
- 2 failed detections → 0.0 points
- **Final score**: (20.0 + 0.5) / 27 = **0.759** (75.9%)

## Key Files Summary

| File | Purpose |
|------|---------|
| `router.py` | API endpoints: `/score`, `/_web`, `/_payload`, `/results` |
| `service.py` | Main orchestration: copies files, runs containers, calculates score |
| `utils.py` | Docker operations: `run_bot_container()`, `stop_container()`, `copy_detection_files()` |
| `_payload_manager.py` | State management: generates sessions, tracks results, calculates score |
| `index.html` | HTML template served to Docker containers |
| `detections/*.js` | Your detection functions (loaded by HTML) |

## Docker Network Architecture

```
┌─────────────────────────────────────┐
│  Challenge Server Container          │
│  (challenger-api)                    │
│  - FastAPI server                    │
│  - Serves /_web endpoint             │
│  - Receives /_payload submissions    │
└──────────────┬──────────────────────┘
               │
               │ Docker Network: "local_network"
               │ Gateway IP: 172.18.0.1
               │
┌──────────────▼──────────────────────┐
│  Automation Framework Containers     │
│  (nodriver, seleniumbase, etc.)     │
│  - Run automation framework         │
│  - Navigate to http://172.18.0.1/_web│
│  - Execute JavaScript                │
│  - Submit results to /_payload      │
└─────────────────────────────────────┘
```

## Important Notes

1. **Detection functions must be synchronous**: They must return `true`/`false` immediately, not use async/await or setTimeout delays.

2. **Detection functions run in isolated browser**: Each Docker container has its own browser instance running the automation framework.

3. **Console logs are not visible**: `console.log()` from detection scripts runs inside Docker containers and is not accessible from the challenge server.

4. **Results must be submitted quickly**: The system waits up to 10 seconds (or 120 seconds for human) for payload submission.

5. **All frameworks tested**: Your detection functions are tested against all 8 automation frameworks + human, in random order, 3 times each.

6. **Human detection is critical**: If you incorrectly detect a framework when it's actually a human, the entire challenge fails (score = 0).

## Debugging Tips

1. **Check server logs**: `docker compose logs -f challenger-api`
   - See which frameworks are being tested
   - See detection results submitted
   - See score calculations

2. **Check container logs**: `docker logs <container_name>`
   - See what the automation framework is doing
   - See if it successfully navigated to the page

3. **Use `/results` endpoint**: After scoring, check `/results` to see all detection results

4. **Test locally first**: Use the test files in `test_files/` to test your detection functions without Docker
