# Debugging Guide: Understanding the 27 Test Sessions

## How 27 Sessions Are Generated

### File: `src/api/endpoints/challenge/_payload_manager.py`

The **27 sessions** are generated in the `gen_ran_framework_sequence()` method:

```python
def gen_ran_framework_sequence(self) -> None:
    # Step 1: Get all 8 automation frameworks + 1 human = 9 total
    frameworks = config.challenge.framework_images.copy()  # 8 frameworks
    frameworks.append(FrameworkImageConfig(name="human", image="none"))  # + 1 human = 9
    
    # Step 2: Repeat 3 times (configured in challenge.yml)
    repeated_frameworks = []
    for _ in range(config.challenge.repeated_framework_count):  # repeated_framework_count: 3
        repeated_frameworks.extend(frameworks)
    
    # Result: 9 frameworks × 3 repetitions = 27 sessions
    
    # Step 3: Randomize the order
    random.shuffle(repeated_frameworks)
    
    # Step 4: Assign order numbers (0-26)
    for _index, _framework in enumerate(repeated_frameworks):
        self.expected_order[_index] = _framework["name"]
        self.tasks[_index] = _framework
```

### Configuration: `src/api/configs/challenge.yml`

```yaml
challenge:
  repeated_framework_count: 3  # This creates 3 repetitions
  framework_images:
    - name: seleniumbase
    - name: seleniumdriverless
    - name: pydoll
    - name: patchright
    - name: zendriver
    - name: nodriver
    - name: botasaurus
    - name: puppeteerextra
    # + 1 human = 9 total
    # 9 × 3 = 27 sessions
```

## Execution Flow

### File: `src/api/endpoints/challenge/service.py`

The `score()` function executes all 27 sessions:

```python
def score(miner_output, web_url):
    # Step 1: Copy detection files
    ch_utils.copy_detection_files(...)
    
    # Step 2: Generate 27 sessions (happens in restart_manager)
    payload_manager.restart_manager()  # Calls gen_ran_framework_sequence()
    _all_tasks = payload_manager.tasks  # Contains 27 tasks (order 0-26)
    
    # Step 3: Execute each session
    for _framework in _all_tasks.values():  # Loop through 27 sessions
        _framework_name = str(_framework["name"])
        _framework_order = _framework["order_number"]  # 0-26
        
        # Run Docker container for automation framework
        # OR wait for human interaction
        
        # Wait for detection results to be submitted
        # Results come via /_payload endpoint
```

## Session Structure

Each session has:
- **order_number**: 0-26 (27 total)
- **expected_framework**: Which framework should be detected
- **status**: CREATED → RUNNING → COMPLETED/TIMED_OUT/FAILED

## How to Debug the 27 Sessions

### 1. Check Expected Sequence

Add this to see the sequence:
```python
# In service.py, after restart_manager()
logger.info(f"Expected framework sequence: {payload_manager.expected_order}")
```

### 2. View All Sessions

The logs now show:
```
=== Task 0: Testing against nodriver ===
=== Task 1: Testing against seleniumbase ===
...
=== Task 26: Testing against human ===
```

### 3. Check Results

After all sessions complete, check:
```bash
curl -H "X-API-Key: your_key" http://localhost:10001/results
```

This shows all 27 submissions with expected vs detected.

## Summary

- **File that generates 27 sessions**: `src/api/endpoints/challenge/_payload_manager.py`
  - Method: `gen_ran_framework_sequence()` (line 118)
  
- **File that executes 27 sessions**: `src/api/endpoints/challenge/service.py`
  - Method: `score()` (line 32)
  - Loop: `for _framework in _all_tasks.values()` (line 54)

- **Configuration**: `src/api/configs/challenge.yml`
  - `repeated_framework_count: 3` (line 5)
  - `framework_images: 8 frameworks` (lines 11-27)

- **Math**: 8 automation frameworks + 1 human = 9 scenarios × 3 repetitions = **27 sessions**
