// patchright.js
// Async detector for "patchright"

function hasNavigator() { return typeof navigator !== "undefined"; }
function uaContains(re) { try { return hasNavigator() && !!navigator.userAgent && re.test(navigator.userAgent); } catch { return false; } }
function getWebEndpoint() { return (typeof window !== "undefined" && (window.ABS_WEB_URL || window.ABS_WEB_ENDPOINT_URL)) || "/web"; }
async function postPayload(payload) { try { await fetch(getWebEndpoint(), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload), keepalive: true }); } catch (e) { try { console.warn("postPayload error", e); } catch {} } }

export async function detect_patchright() {
  try {
    if (uaContains(/patchright/i)) return true;
    try { if (typeof document !== "undefined") { if (document.querySelector("[data-patchright],[data-pr]")) return true; } } catch {}
  } catch {}
  return false;
}

(async () => {
  const detected = await detect_patchright();
  await postPayload({ framework: detected ? ["patchright"] : [], detected: !!detected, ts: Date.now() });
})();