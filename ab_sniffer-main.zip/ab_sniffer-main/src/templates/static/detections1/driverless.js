// selenium_driverless.js
// Async detector for "selenium_driverless"

function hasNavigator() { return typeof navigator !== "undefined"; }
function uaContains(re) { try { return hasNavigator() && !!navigator.userAgent && re.test(navigator.userAgent); } catch { return false; } }
function isWebDriver() { try { if (hasNavigator() && navigator.webdriver === true) return true; if (typeof document !== "undefined") { const attr = document.documentElement?.getAttribute("webdriver"); if (attr === "true") return true; } if (typeof window !== "undefined") { if (window.__driver || window.__webdriver || window.__SE_AUTOMATION__) return true; } } catch {} return false; }
function looksHeadless() { try { if (uaContains(/HeadlessChrome|Headless/i)) return true; if (hasNavigator() && (!navigator.plugins || navigator.plugins.length === 0)) return true; if (hasNavigator() && (!navigator.languages || navigator.languages.length === 0)) return true; if (typeof window !== "undefined" && window.outerWidth === 0 && window.outerHeight === 0) return true; } catch {} return false; }
function getWebEndpoint() { return (typeof window !== "undefined" && (window.ABS_WEB_URL || window.ABS_WEB_ENDPOINT_URL)) || "/web"; }
async function postPayload(payload) { try { await fetch(getWebEndpoint(), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload), keepalive: true }); } catch (e) { try { console.warn("postPayload error", e); } catch {} } }

export async function detect_selenium_driverless() {
  try {
    if (uaContains(/driverless/i)) return true;
    if (isWebDriver() && looksHeadless()) return true;
    if (!isWebDriver() && looksHeadless() && uaContains(/HeadlessChrome|PhantomJS|Headless/)) return true;
  } catch {}
  return false;
}

(async () => {
  const detected = await detect_selenium_driverless();
  await postPayload({ framework: detected ? ["selenium_driverless"] : [], detected: !!detected, ts: Date.now() });
})();