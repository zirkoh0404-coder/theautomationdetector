// zendriver.js
// Async detector for "zendriver"

function hasNavigator() { return typeof navigator !== "undefined"; }
function uaContains(re) { try { return hasNavigator() && !!navigator.userAgent && re.test(navigator.userAgent); } catch { return false; } }
function isWebDriver() { try { if (hasNavigator() && navigator.webdriver === true) return true; if (typeof document !== "undefined") { const attr = document.documentElement?.getAttribute("webdriver"); if (attr === "true") return true; } if (typeof window !== "undefined") { if (window.__driver || window.__webdriver || window.__SE_AUTOMATION__) return true; } } catch {} return false; }
function getWebEndpoint() { return (typeof window !== "undefined" && (window.ABS_WEB_URL || window.ABS_WEB_ENDPOINT_URL)) || "/web"; }
async function postPayload(payload) { try { await fetch(getWebEndpoint(), { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload), keepalive: true }); } catch (e) { try { console.warn("postPayload error", e); } catch {} } }

export async function detect_zendriver() {
  try {
    if (uaContains(/zendriver/i)) return true;
    if (typeof window !== "undefined" && (window.zendriver || window.__zendriver__)) return true;
    if (isWebDriver()) return true;
  } catch {}
  return false;
}

(async () => {
  const detected = await detect_zendriver();
  await postPayload({ framework: detected ? ["zendriver"] : [], detected: !!detected, ts: Date.now() });
})();