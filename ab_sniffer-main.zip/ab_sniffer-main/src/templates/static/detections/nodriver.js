function detect_nodriver() {
  try {
    if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
    if (navigator.webdriver === true) return false;
    if (document.$cdc_ || document.__$webdriverAsyncExecutor) return false;
    if (window.cdc_adoQpoasnfa76pfcZLmcfl_Array) return false;
    if (window.selenium_driverless_context_manager !== undefined || window.__selenium_driverless__ !== undefined) return false;
    if (window.SB_UC_MODE !== undefined || window.HTMLInspector !== undefined) return false;
    if (window.__pwInitScripts !== undefined || window.__puppeteer_extra__ !== undefined || window.stripProxyFromErrors !== undefined) return false;
    if (typeof window.nodriver_internal_function !== 'undefined') return true;
    if (document.body && typeof document.body.nodriver_element_id !== 'undefined') return true;
    var props = Object.getOwnPropertyNames(window).concat(document ? Object.getOwnPropertyNames(document) : []);
    if (/nodriver_internal_function|nodriver_element_id/.test(props.join(' ').toLowerCase())) return true;
    var d = Object.getOwnPropertyDescriptor(navigator, 'webdriver');
    if (d && d.get) {
      var g = d.get.toString().toLowerCase();
      if (g.indexOf('nodriver') !== -1 && g.indexOf('puppeteer') === -1 && g.indexOf('seleniumbase') === -1 && g.indexOf('botasaurus') === -1 && g.indexOf('patchright') === -1 && g.indexOf('zendriver') === -1 && g.indexOf('pydoll') === -1 && g.indexOf('selenium_driverless') === -1) return true;
    }
    var st = (new Error()).stack || '';
    if (st.toLowerCase().indexOf('nodriver') !== -1) return true;
  } catch (e) {}
  return false;
}
if (typeof window !== 'undefined') window.detect_nodriver = detect_nodriver;
