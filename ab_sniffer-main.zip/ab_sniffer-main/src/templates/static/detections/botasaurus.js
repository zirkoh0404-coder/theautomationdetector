function detect_botasaurus() {
  try {
    if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
    if (typeof window.botasaurus_human_type !== 'undefined') return true;
    if (typeof window.__botasaurus__ !== 'undefined') return true;
    if (typeof window.botasaurus_config !== 'undefined') return true;
    if ((window.__pwInitScripts !== undefined || window.__pw_original || window.__pw_originalObject) && !window.patchright_active_flag && !window.__patchright__) return true;
    var props = Object.getOwnPropertyNames(window).join(' ').toLowerCase();
    if (/botasaurus_human_type|__botasaurus__|botasaurus_config/.test(props)) return true;
    if (/__pw_original|__pw_originalobject|__pwinitscripts/.test(props) && props.indexOf('patchright') === -1) return true;
    var d = Object.getOwnPropertyDescriptor(navigator, 'webdriver');
    if (d && d.get) {
      var g = d.get.toString().toLowerCase();
      if (g.indexOf('botasaurus') !== -1 && g.indexOf('patchright') === -1 && g.indexOf('puppeteer') === -1) return true;
    }
    var st = (new Error()).stack || '';
    if (st.toLowerCase().indexOf('botasaurus') !== -1) return true;
  } catch (e) {}
  return false;
}
if (typeof window !== 'undefined') window.detect_botasaurus = detect_botasaurus;
