function detect_seleniumbase() {
  try {
    if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
    if (typeof window.SB_UC_MODE !== 'undefined') return true;
    if (typeof window.HTMLInspector !== 'undefined') return true;
    if (typeof window.SB_OPTIONS !== 'undefined') return true;
    if (window.cdc_adoQpoasnfa76pfcZLmcfl_Array) return true;
    if (window.cdc_adoQpoasnfa76pfcZLmcfl_Promise) return true;
    if (window.cdc_adoQpoasnfa76pfcZLmcfl_Symbol) return true;
    for (var k in window) { if (k.indexOf('cdc_') === 0) return true; }
    if (navigator.webdriver === true) return true;
    if (document.$cdc_ !== undefined || document.__$webdriverAsyncExecutor !== undefined) return true;
    var docProps = Object.getOwnPropertyNames(document);
    for (var i = 0; i < docProps.length; i++) {
      var p = docProps[i];
      if (p.indexOf('$cdc') !== -1 || p.indexOf('webdriver') !== -1 || p.indexOf('cdc_') !== -1) return true;
    }
    if ((window.__selenium_unwrapped || window.__selenium_evaluate) && (navigator.webdriver === true || window.SB_UC_MODE !== undefined || window.cdc_adoQpoasnfa76pfcZLmcfl_Array)) return true;
    var winStr = Object.getOwnPropertyNames(window).join(' ').toLowerCase();
    if (/sb_uc_mode|htmlinspector|sb_options|cdc_adoqpoasnfa76pfcZLmcfl|__selenium_unwrapped|__selenium_evaluate/.test(winStr)) return true;
    var d = Object.getOwnPropertyDescriptor(navigator, 'webdriver');
    if (d && d.get) {
      var g = d.get.toString().toLowerCase();
      if (g.indexOf('selenium') !== -1 && g.indexOf('driverless') === -1 && g.indexOf('puppeteer') === -1 && g.indexOf('nodriver') === -1) return true;
    }
    var st = (new Error()).stack || '';
    if (st.toLowerCase().indexOf('seleniumbase') !== -1) return true;
  } catch (e) {}
  return false;
}
if (typeof window !== 'undefined') window.detect_seleniumbase = detect_seleniumbase;
