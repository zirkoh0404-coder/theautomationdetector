function detect_patchright() {
  try {
    if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
    if (typeof window.patchright_active_flag === 'boolean' && window.patchright_active_flag === true) return true;
    if (typeof window.__patchright__ !== 'undefined') return true;
    if (typeof window.patchright_injected !== 'undefined') return true;
    if ((window.__pwInitScripts !== undefined || window.__pw_original || window.__pw_originalObject) && !window.botasaurus_human_type && !window.__botasaurus__) return true;
    var props = Object.getOwnPropertyNames(window).join(' ').toLowerCase();
    if (/patchright_active_flag|__patchright__|patchright_injected/.test(props)) return true;
    if (/__pw_original|__pw_originalobject|__pwinitscripts/.test(props) && props.indexOf('botasaurus') === -1) return true;
    var d = Object.getOwnPropertyDescriptor(navigator, 'webdriver');
    if (d && d.get) {
      var g = d.get.toString().toLowerCase();
      if (g.indexOf('patchright') !== -1 && g.indexOf('botasaurus') === -1 && g.indexOf('puppeteer') === -1) return true;
    }
    var st = (new Error()).stack || '';
    if (st.toLowerCase().indexOf('patchright') !== -1) return true;
  } catch (e) {}
  return false;
}
if (typeof window !== 'undefined') window.detect_patchright = detect_patchright;
