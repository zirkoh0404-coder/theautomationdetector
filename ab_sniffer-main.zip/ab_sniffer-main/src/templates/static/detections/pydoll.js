function detect_pydoll() {
  try {
    if (typeof window === 'undefined' || typeof navigator === 'undefined') return false;
    if (typeof window.pydoll_scripts_container !== 'undefined') return true;
    if (typeof window.__pydoll__ !== 'undefined') return true;
    if (typeof window.pydoll_injected !== 'undefined') return true;
    var props = Object.getOwnPropertyNames(window).concat(document && document.body ? Object.getOwnPropertyNames(document.body) : []);
    if (/pydoll_scripts_container|__pydoll__|pydoll_injected/.test(props.join(' ').toLowerCase())) return true;
    var d = Object.getOwnPropertyDescriptor(navigator, 'webdriver');
    if (d && d.get) {
      var g = d.get.toString().toLowerCase();
      if (g.indexOf('pydoll') !== -1) return true;
    }
    var st = (new Error()).stack || '';
    if (st.toLowerCase().indexOf('pydoll') !== -1) return true;
  } catch (e) {}
  return false;
}
if (typeof window !== 'undefined') window.detect_pydoll = detect_pydoll;
