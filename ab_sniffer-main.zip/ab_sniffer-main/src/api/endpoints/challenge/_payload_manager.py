import random

from pydantic import validate_call
from api.config import config
from api.logger import logger
from api.endpoints.challenge.schemas import TaskStatusEnum
from api.core.configs._challenge import FrameworkImageConfig


class PayloadManager:
    @validate_call
    def __init__(self):
        self.tasks: dict[int, dict] = {}
        self.current_task: dict | None = None
        self.submitted_payloads: dict[int, dict] = {}
        self.expected_order: dict[int, str] = {}
        self.score: float = 0.0

        self.gen_ran_framework_sequence()
        return

    def restart_manager(self) -> None:
        self.tasks = {}
        self.current_task = None
        self.submitted_payloads = {}
        self.expected_order = {}
        self.score = 0.0

        self.gen_ran_framework_sequence()
        return

    def submit_task(self, framework_names: list[str], payload: dict) -> None:
        try:
            _order_number = payload["order_number"]
            _expected_fm = self.expected_order[_order_number]
            _is_detected = _expected_fm in framework_names
            _is_collided = len(framework_names) > 1

            if _expected_fm == "human":
                _is_detected = True if len(framework_names) == 0 else False
                _is_collided = True if len(framework_names) > 0 else False

            logger.info(
                f"PayloadManager: Order {_order_number} - "
                f"Expected: {_expected_fm}, "
                f"Submitted: {framework_names}, "
                f"Detected: {_is_detected}, "
                f"Collision: {_is_collided}"
            )

            self.submitted_payloads[_order_number] = {
                "expected_framework": _expected_fm,
                "submitted_framework": framework_names,
                "detected": _is_detected,
                "collided": _is_collided,
            }

        except Exception as err:
            logger.error(f"Failed to add submitted payload: {err}!")
            raise
        return

    def calculate_score(self) -> float:
        _total_tasks = len(self.expected_order)
        logger.info(f"Calculating score for {_total_tasks} tasks")

        # Check human detection first
        for order_num, submission in self.submitted_payloads.items():
            if order_num == "final_score":
                continue
            if submission["expected_framework"] == "human":
                if submission["collided"] or not submission["detected"]:
                    logger.warning(
                        f"Human detection failed - Order {order_num}: "
                        f"Detected frameworks: {submission['submitted_framework']}, "
                        f"Collision: {submission['collided']}, "
                        f"Detected: {submission['detected']}"
                    )
                    logger.warning("Couldn't detect human correctly, score is zero")
                    return 0.0
                else:
                    logger.info(f"Human detection passed for order {order_num}")

        _correct_detections = 0
        _collision_detections = 0
        _failed_detections = 0
        
        for order_num, submission in self.submitted_payloads.items():
            if order_num == "final_score":
                continue
            if submission["detected"]:
                if not submission["collided"]:
                    _correct_detections += 1
                    logger.info(f"Order {order_num}: Perfect detection (+1.0)")
                else:
                    _collision_detections += 1
                    logger.info(f"Order {order_num}: Collision detection (+0.1)")
            else:
                _failed_detections += 1
                logger.warning(f"Order {order_num}: Failed detection (+0.0)")

        _total_points = _correct_detections * 1.0 + _collision_detections * 0.1

        if _total_tasks == 0:
            logger.warning("No tasks found, score is zero")
            return 0.0

        self.score = _total_points / _total_tasks
        logger.info(
            f"Score breakdown: Perfect={_correct_detections}, "
            f"Collisions={_collision_detections}, "
            f"Failed={_failed_detections}, "
            f"Total points={_total_points}, "
            f"Final score={self.score}"
        )
        return self.score

    def gen_ran_framework_sequence(self) -> None:
        frameworks = config.challenge.framework_images.copy()
        # Exclude nodriver for testing
        # frameworks = [f for f in frameworks if f.name == "nodriver"]
        frameworks.append(FrameworkImageConfig(name="human", image="none"))
        repeated_frameworks = []

        for _ in range(config.challenge.repeated_framework_count):
            repeated_frameworks.extend(frameworks)

        random.shuffle(repeated_frameworks)

        for _index, _framework in enumerate(repeated_frameworks):
            _framework = _framework.model_dump()
            self.expected_order[_index] = _framework["name"]
            _framework["order_number"] = _index
            _framework["status"] = TaskStatusEnum.CREATED
            self.tasks[_index] = _framework

        return

    def update_task_status(self, order_number: int, new_status: TaskStatusEnum):
        if self.tasks[order_number] and self.tasks[order_number]["status"]:
            self.tasks[order_number]["status"] = new_status
        else:
            logger.error(
                f"Couldn't update status of task with order_number: {order_number}"
            )

    def check_task_compliance(self, order_number: int) -> bool:
        if order_number in self.submitted_payloads:
            return True
        return False

    def get_submission_report(self) -> dict[int, dict]:
        return self.submitted_payloads


payload_manager = PayloadManager()

__all__ = [
    "PayloadManager",
    "payload_manager",
]
