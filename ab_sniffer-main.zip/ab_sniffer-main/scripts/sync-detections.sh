#!/bin/bash
# Sync detection files between testing and miner build locations

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

TESTING_DIR="$PROJECT_ROOT/src/templates/static/detections"
MINER_DIR="$PROJECT_ROOT/templates/commit/src/detections"

echo "Syncing detection files..."
echo "From: $TESTING_DIR"
echo "To: $MINER_DIR"
echo ""

# Check if source directory exists
if [ ! -d "$TESTING_DIR" ]; then
    echo "Error: Testing directory not found: $TESTING_DIR"
    exit 1
fi

# Create destination directory if it doesn't exist
mkdir -p "$MINER_DIR"

# Copy all .js files
echo "Copying detection files..."
cp -v "$TESTING_DIR"/*.js "$MINER_DIR/" 2>/dev/null || {
    echo "Warning: No .js files found in $TESTING_DIR"
    echo "Make sure you have implemented your detection files first!"
    exit 1
}

echo ""
echo "✓ Successfully synced detection files!"
echo ""
echo "Files synced:"
ls -1 "$MINER_DIR"/*.js | xargs -n1 basename
